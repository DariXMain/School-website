// Made by DariX Amirali Alinejad

async function loadJSON() {
    try {
        const response = await fetch('/data/Top_Students.json');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('خطا در بارگذاری JSON:', error);
    }
}

function Reload_list() {
    var cls = document.getElementById("class").value;
    var field = document.getElementById("field").value;
    var sortby = document.getElementById("sortby").value;
    var main_list = document.getElementById("list-list");

    loadJSON().then(data => {

        if (data && data[cls] && data[cls][field]) {
            var students = data[cls][field];
            var item = "";
            var index = 0;
            students.sort((a, b) => parseFloat(b[sortby]) - parseFloat(a[sortby]));
            students.forEach(student => {
                index++;
                item += `
                    <nav class="student-item">
                        <h2>${index}</h2>
                        <h3>${student.firstname} ${student.lastname}</h3>
                        <p>معدل: ${student.GPA}</p>
                        <p>پیشرفت تحصیلی: ${student.Academic_progress * 10}</p>
                        <p>امتیاز: ${student.Score}</p>
                    </nav>
                `;
            });

            main_list.innerHTML = item;

            document.querySelectorAll(".student-item").forEach((item, i) => {
                setTimeout(() => {
                    item.style.opacity = "1";
                }, i * 200);
            });

        } else {
            console.error("داده‌ای یافت نشد!");
            main_list.innerHTML = "<p>داده‌ای برای نمایش وجود ندارد</p>";
        }

    }).catch(error => {
        console.error("خطا در بارگذاری JSON:", error);
        main_list.innerHTML = "<p>خطا در بارگذاری داده‌ها</p>";
    });
}

document.addEventListener("DOMContentLoaded", function () {
    Reload_list()
    var elements = document.getElementsByClassName("select-design");
    for (let index = 0; index < elements.length; index++) {
        elements[index].addEventListener("change", function () {
            Reload_list();
        })
    }

});

