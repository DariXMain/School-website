// Made by DariX - Amirali Alinejad

function Load_page() {
    let header = document.getElementById("header");
    window.addEventListener("scroll", function () {
        if (window.innerWidth < 991.98) {
            return false;
        }
        if (window.scrollY > 500) {
            header.style.position = "sticky";
            header.style.scale = "0.7"
            header.style.borderRadius = "1.2rem"
            header.style.transition = "all 1.2s"
            header.style.boxShadow = "0 0 10px 1px black"
        } else {
            header.style.position = "relative";
            header.style.scale = "1"
            header.style.borderRadius = "0"
            header.style.transition = "none"
            header.style.boxShadow = "none"
        }
    })

    var element = document.getElementById("mobile-item-shower");
    var element2 = document.getElementById("menu-btn");
    window.addEventListener('click', function (ev) {
        if (element.style.visibility === "visible" || window.getComputedStyle(element).visibility === "visible") {
            if (!element.contains(ev.target)) {
                Load_Mobile_Menu();
            }
        } else {
            if (element2.contains(ev.target)) {
                Load_Mobile_Menu();
            }
        }
    });

    var math = document.getElementById("math");
    math.addEventListener("click", function () {
        window.scrollTo({
            top: 400,
            behavior: 'smooth'
        });
    })

    var persian = document.getElementById("persian");
    persian.addEventListener("click", function () {
        window.scrollTo({
            top: 1400,
            behavior: 'smooth'
        });
    })

    var network = document.getElementById("network");
    network.addEventListener("click", function () {
        window.scrollTo({
            top: 2300,
            behavior: 'smooth'
        });
    })

    var memari = document.getElementById("memari");
    memari.addEventListener("click", function () {
        window.scrollTo({
            top: 3300,
            behavior: 'smooth'
        });
    })
}

window.onload = Load_page;

function goto_Call_to_we() {
    window.scrollTo({
        top: document.body.scrollHeight - 50,
        behavior: 'smooth'
    });
}

function Load_Mobile_Menu() {
    var element = document.getElementById("mobile-item-shower");

    if (element.style.visibility === "hidden" || element.style.visibility === "") {
        element.style.width = "25%";
        element.style.visibility = "visible";
        element.style.opacity = "1";
    } else {
        element.style.width = "0%";
        element.style.visibility = "hidden";
        element.style.opacity = "0";
    }
}